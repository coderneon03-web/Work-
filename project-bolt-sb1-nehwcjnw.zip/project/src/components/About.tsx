import React from 'react';
import { Target, Heart, Zap, Award } from 'lucide-react';

const About = () => {
  const values = [
    {
      icon: Heart,
      title: 'Community First',
      description: 'We prioritize our players and their experience above everything else'
    },
    {
      icon: Zap,
      title: 'Innovation',
      description: 'Constantly improving and adding new features to enhance gameplay'
    },
    {
      icon: Award,
      title: 'Quality',
      description: 'Maintaining the highest standards in server performance and support'
    },
    {
      icon: Target,
      title: 'Excellence',
      description: 'Striving to be the best Minecraft server experience possible'
    }
  ];

  return (
    <section id="about" className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50 dark:bg-gray-800/50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-6">
            About AllySmp
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Founded with a vision to create the ultimate Minecraft SMP experience, AllySmp has grown 
            into a thriving community where players come together to build, compete, and connect.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">Our Story</h3>
            <div className="space-y-4 text-gray-600 dark:text-gray-300">
              <p>
                AllySmp began as a small passion project by a group of dedicated Minecraft enthusiasts 
                who wanted to create something special. What started as a simple server has evolved into 
                a comprehensive gaming platform with thousands of active players.
              </p>
              <p>
                Our commitment to excellence, innovative features, and exceptional community support 
                has made us one of the most trusted names in the Minecraft server space. We're proud 
                to have built a place where players of all skill levels feel welcome and valued.
              </p>
              <p>
                Today, we continue to push boundaries, introduce new features, and maintain the 
                highest standards of gameplay quality and community engagement.
              </p>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-6">
            {values.map((value, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900/30 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <value.icon className="h-8 w-8 text-blue-600" />
                </div>
                <h4 className="font-bold text-gray-900 dark:text-white mb-2">{value.title}</h4>
                <p className="text-sm text-gray-600 dark:text-gray-300">{value.description}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-3xl p-8 lg:p-12 shadow-xl border border-gray-200 dark:border-gray-700">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Built by Gamers, for Gamers
            </h3>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Every decision we make is guided by our understanding of what makes a great SMP experience.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-blue-600 mb-2">5+</div>
              <div className="text-gray-600 dark:text-gray-300">Years of Experience</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-purple-600 mb-2">24/7</div>
              <div className="text-gray-600 dark:text-gray-300">Server Uptime</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-green-600 mb-2">50K+</div>
              <div className="text-gray-600 dark:text-gray-300">Happy Players</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;