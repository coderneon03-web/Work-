import React from 'react';
import { Crown, Star, Code, Shield, Hammer, Heart } from 'lucide-react';

const Staff = () => {
  const staffRoles = [
    {
      title: 'Owners',
      icon: Crown,
      color: 'text-yellow-500',
      bgColor: 'bg-yellow-50 dark:bg-yellow-900/20',
      members: ['Immortal3D', 'DARKKING17'],
      description: 'Server founders and ultimate decision makers'
    },
    {
      title: 'Manager',
      icon: Star,
      color: 'text-blue-500',
      bgColor: 'bg-blue-50 dark:bg-blue-900/20',
      members: ['Slushy'],
      description: 'Oversees daily operations and staff coordination'
    },
    {
      title: 'Developers',
      icon: Code,
      color: 'text-green-500',
      bgColor: 'bg-green-50 dark:bg-green-900/20',
      members: ['LightxD', 'baggybrake', 'Black', 'IamFakeOp'],
      description: 'Create and maintain server features and plugins'
    },
    {
      title: 'Admins',
      icon: Shield,
      color: 'text-red-500',
      bgColor: 'bg-red-50 dark:bg-red-900/20',
      members: ['Svly', 'Mayan'],
      description: 'Handle major issues and player disputes'
    },
    {
      title: 'Moderators',
      icon: Hammer,
      color: 'text-orange-500',
      bgColor: 'bg-orange-50 dark:bg-orange-900/20',
      members: ['Haise XD', 'Tibtrin', 'kai295'],
      description: 'Maintain order and enforce server rules'
    },
    {
      title: 'Helpers',
      icon: Heart,
      color: 'text-purple-500',
      bgColor: 'bg-purple-50 dark:bg-purple-900/20',
      members: ['PhoebexD', 'TsgGamerz'],
      description: 'Assist new players and answer questions'
    }
  ];

  return (
    <section id="staff" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-6">
            Meet Our Team
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Our dedicated staff team works around the clock to ensure you have the best 
            possible experience on AllySmp. Each member brings unique skills and passion to our community.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {staffRoles.map((role, index) => (
            <div
              key={index}
              className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg hover:shadow-xl 
                       transition-all duration-300 transform hover:-translate-y-2 border border-gray-200 dark:border-gray-700"
            >
              <div className={`w-16 h-16 ${role.bgColor} rounded-2xl flex items-center justify-center mb-6`}>
                <role.icon className={`h-8 w-8 ${role.color}`} />
              </div>
              
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                {role.title}
              </h3>
              
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                {role.description}
              </p>
              
              <div className="space-y-2">
                {role.members.map((member, memberIndex) => (
                  <div
                    key={memberIndex}
                    className={`px-4 py-2 ${role.bgColor} rounded-lg font-medium ${role.color} 
                             hover:scale-105 transition-transform duration-200 cursor-default`}
                  >
                    {member}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-8 text-white">
            <h3 className="text-3xl font-bold mb-4">Interested in Joining Our Team?</h3>
            <p className="text-xl mb-8 opacity-90">
              We're always looking for passionate, dedicated individuals to help make AllySmp even better.
            </p>
            <a
              href="https://discord.gg/Hv2CA4Pn"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center px-8 py-4 bg-white text-gray-900 font-semibold 
                       rounded-xl hover:bg-gray-100 transition-all duration-300 transform hover:scale-105"
            >
              Apply on Discord
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Staff;