import React from 'react';
import { MessageSquare, Users, Mic, Hash } from 'lucide-react';

const Discord = () => {
  const features = [
    {
      icon: Hash,
      title: 'Dedicated Channels',
      description: 'Separate channels for support, general chat, updates, and more'
    },
    {
      icon: Users,
      title: 'Active Community',
      description: 'Connect with players, share builds, and make lasting friendships'
    },
    {
      icon: Mic,
      title: 'Voice Channels',
      description: 'Join voice chats for team coordination and casual conversations'
    },
    {
      icon: MessageSquare,
      title: 'Direct Support',
      description: 'Get help directly from our staff team in dedicated support channels'
    }
  ];

  return (
    <section id="discord" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-4 py-2 bg-purple-100 dark:bg-purple-900/30 rounded-full mb-6">
            <MessageSquare className="h-5 w-5 text-purple-600 mr-2" />
            <span className="text-purple-700 dark:text-purple-300 font-medium">Discord Community</span>
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-6">
            Join Our Discord Server
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Connect with our amazing community, get support, participate in events, 
            and stay updated with the latest server news and announcements.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="space-y-8">
              {features.map((feature, index) => (
                <div key={index} className="flex items-start">
                  <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 rounded-xl flex items-center justify-center mr-4 flex-shrink-0">
                    <feature.icon className="h-6 w-6 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                      {feature.title}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-300">
                      {feature.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gradient-to-br from-purple-500 to-blue-600 rounded-3xl p-8 text-white text-center">
            <div className="mb-8">
              <MessageSquare className="h-20 w-20 mx-auto mb-4 opacity-80" />
              <h3 className="text-3xl font-bold mb-4">Join Now!</h3>
              <p className="text-xl opacity-90 mb-8">
                Become part of our growing community of over 10,000 members
              </p>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 mb-8">
              <div className="text-3xl font-bold mb-2">10,247</div>
              <div className="opacity-80">Active Members</div>
            </div>

            <a
              href="https://discord.gg/Hv2CA4Pn"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center px-8 py-4 bg-white text-purple-600 font-semibold 
                       rounded-xl hover:bg-gray-100 transition-all duration-300 transform hover:scale-105"
            >
              <MessageSquare className="h-5 w-5 mr-2" />
              Join Discord Server
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Discord;