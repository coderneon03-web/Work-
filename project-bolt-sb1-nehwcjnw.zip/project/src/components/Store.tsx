import React, { useState, useEffect } from 'react';
import { Crown, Package, Check, ExternalLink } from 'lucide-react';

interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  features: string[];
}

interface ProductData {
  ranks: Product[];
  kits: Product[];
}

const Store = () => {
  const [products, setProducts] = useState<ProductData>({ ranks: [], kits: [] });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/products')
      .then(res => res.json())
      .then(data => {
        setProducts(data);
        setLoading(false);
      })
      .catch(error => {
        console.error('Failed to fetch products:', error);
        setLoading(false);
      });
  }, []);

  const handlePurchase = (product: Product) => {
    // Simulate PayPal integration
    const confirmed = confirm(`Purchase ${product.name} for $${product.price}?\n\nThis will redirect you to PayPal for secure payment.`);
    if (confirmed) {
      // In production, this would integrate with PayPal SDK
      alert(`Redirecting to PayPal for ${product.name} - $${product.price}\n\nAfter payment, you'll receive your items in-game within 5 minutes.`);
    }
  };

  if (loading) {
    return (
      <section id="store" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <div className="animate-pulse">Loading store...</div>
        </div>
      </section>
    );
  }

  return (
    <section id="store" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-6">
            Premium Store
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Enhance your gameplay with exclusive ranks and powerful kits. 
            Support the server while unlocking amazing perks and features.
          </p>
        </div>

        {/* Ranks Section */}
        <div className="mb-20">
          <div className="flex items-center justify-center mb-12">
            <Crown className="h-8 w-8 text-yellow-500 mr-3" />
            <h3 className="text-3xl font-bold text-gray-900 dark:text-white">Premium Ranks</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {products.ranks.map((rank, index) => (
              <div
                key={rank.id}
                className={`relative bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg hover:shadow-xl 
                           transition-all duration-300 transform hover:-translate-y-2 border ${
                  index === products.ranks.length - 1 
                    ? 'border-yellow-500 ring-2 ring-yellow-500/20' 
                    : 'border-gray-200 dark:border-gray-700'
                }`}
              >
                {index === products.ranks.length - 1 && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <span className="bg-yellow-500 text-white px-4 py-1 rounded-full text-sm font-semibold">
                      Premium Choice
                    </span>
                  </div>
                )}
                
                <div className="text-center mb-6">
                  <h4 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">{rank.name}</h4>
                  <div className="text-3xl font-bold text-blue-600 mb-2">${rank.price}</div>
                  <p className="text-gray-600 dark:text-gray-400">{rank.description}</p>
                </div>

                <ul className="space-y-3 mb-8">
                  {rank.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center text-gray-700 dark:text-gray-300">
                      <Check className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <button
                  onClick={() => handlePurchase(rank)}
                  className={`w-full py-3 px-6 rounded-xl font-semibold transition-all duration-300 transform hover:scale-105 ${
                    index === products.ranks.length - 1
                      ? 'bg-yellow-500 hover:bg-yellow-600 text-white'
                      : 'bg-blue-600 hover:bg-blue-700 text-white'
                  }`}
                >
                  Purchase Now
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Kits Section */}
        <div>
          <div className="flex items-center justify-center mb-12">
            <Package className="h-8 w-8 text-purple-500 mr-3" />
            <h3 className="text-3xl font-bold text-gray-900 dark:text-white">Power Kits</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-8">
            {products.kits.map((kit) => (
              <div
                key={kit.id}
                className={`relative bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg hover:shadow-xl 
                         transition-all duration-300 transform hover:-translate-y-2 border ${
                  kit.id === 'starter-kit' 
                    ? 'border-green-500 ring-2 ring-green-500/20' 
                    : 'border-gray-200 dark:border-gray-700'
                }`}
              >
                {kit.id === 'starter-kit' && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <span className="bg-green-500 text-white px-4 py-1 rounded-full text-sm font-semibold">
                      Best Value
                    </span>
                  </div>
                )}
                
                <div className="text-center mb-6">
                  <h4 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">{kit.name}</h4>
                  <div className={`text-3xl font-bold mb-2 ${
                    kit.id === 'starter-kit' ? 'text-green-600' : 'text-purple-600'
                  }`}>${kit.price}</div>
                  <p className="text-gray-600 dark:text-gray-400">{kit.description}</p>
                </div>

                <ul className="space-y-3 mb-8">
                  {kit.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center text-gray-700 dark:text-gray-300">
                      <Check className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <button
                  onClick={() => handlePurchase(kit)}
                  className={`w-full py-3 px-6 rounded-xl font-semibold transition-all duration-300 transform hover:scale-105 ${
                    kit.id === 'starter-kit'
                      ? 'bg-green-600 hover:bg-green-700 text-white'
                      : 'bg-purple-600 hover:bg-purple-700 text-white'
                  }`}
                >
                  Get Kit
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="text-center mt-16">
          <div className="bg-blue-50 dark:bg-blue-900/20 rounded-2xl p-8 border border-blue-200 dark:border-blue-800">
            <h4 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Need Help Choosing?</h4>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              Our staff team is here to help you find the perfect rank or kit for your playstyle.
            </p>
            <a
              href="https://discord.gg/Hv2CA4Pn"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white 
                       rounded-xl font-semibold transition-all duration-300"
            >
              Ask on Discord
              <ExternalLink className="ml-2 h-5 w-5" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Store;