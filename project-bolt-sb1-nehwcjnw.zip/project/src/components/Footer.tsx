import React from 'react';
import { Gamepad2, MessageSquare, Mail, ExternalLink } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    'Quick Links': [
      { name: 'Store', href: '#store' },
      { name: 'Benefits', href: '#benefits' },
      { name: 'About', href: '#about' },
      { name: 'Staff', href: '#staff' }
    ],
    'Community': [
      { name: 'Discord Server', href: 'https://discord.gg/Hv2CA4Pn', external: true },
      { name: 'Support', href: '#contact' },
      { name: 'Events', href: '#discord' },
      { name: 'Guidelines', href: '#about' }
    ],
    'Support': [
      { name: 'Contact Us', href: '#contact' },
      { name: 'FAQ', href: '#benefits' },
      { name: 'Help Center', href: 'https://discord.gg/Hv2CA4Pn', external: true },
      { name: 'Bug Reports', href: 'https://discord.gg/Hv2CA4Pn', external: true }
    ]
  };

  return (
    <footer className="bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-8">
          {/* Brand Section */}
          <div className="lg:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <Gamepad2 className="h-8 w-8 text-blue-600" />
              <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                AllySmp
              </span>
            </div>
            <p className="text-gray-600 dark:text-gray-400 mb-6 max-w-md">
              The ultimate Minecraft server experience with exclusive ranks, powerful kits, 
              and an amazing community. Join thousands of players in our world of endless possibilities.
            </p>
            <div className="flex space-x-4">
              <a
                href="https://discord.gg/E6mryGpF"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center 
                         text-blue-600 hover:bg-blue-200 dark:hover:bg-blue-900/50 transition-colors duration-200"
                aria-label="Discord"
              >
                <MessageSquare className="h-5 w-5" />
              </a>
              <a
                href="mailto:coderneon03@gmail.com"
                className="w-10 h-10 bg-purple-100 dark:bg-purple-900/30 rounded-lg flex items-center justify-center 
                         text-purple-600 hover:bg-purple-200 dark:hover:bg-purple-900/50 transition-colors duration-200"
                aria-label="Email"
              >
                <Mail className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Footer Links */}
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h3 className="text-sm font-semibold text-gray-900 dark:text-white uppercase tracking-wider mb-4">
                {category}
              </h3>
              <ul className="space-y-3">
                {links.map((link) => (
                  <li key={link.name}>
                    <a
                      href={link.href}
                      target={link.external ? "_blank" : undefined}
                      rel={link.external ? "noopener noreferrer" : undefined}
                      className="text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 
                               transition-colors duration-200 flex items-center"
                    >
                      {link.name}
                      {link.external && <ExternalLink className="h-3 w-3 ml-1" />}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Server Status */}
        <div className="bg-gray-50 dark:bg-gray-800/50 rounded-2xl p-6 mb-8">
          <div className="flex flex-col sm:flex-row items-center justify-between">
            <div className="flex items-center mb-4 sm:mb-0">
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse mr-3"></div>
              <span className="text-gray-900 dark:text-white font-medium">Server Status: Online</span>
            </div>
            <div className="flex items-center space-x-6 text-sm text-gray-600 dark:text-gray-400">
              <div>Players Online: <span className="font-semibold text-gray-900 dark:text-white">247</span></div>
              <div>Uptime: <span className="font-semibold text-green-600">99.9%</span></div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between pt-8 border-t border-gray-200 dark:border-gray-800">
          <div className="text-gray-600 dark:text-gray-400 mb-4 sm:mb-0">
            &copy; {currentYear} AllySmp. All rights reserved.
          </div>
          <div className="flex space-x-6 text-sm text-gray-600 dark:text-gray-400">
            <a href="#" className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors duration-200">
              Privacy Policy
            </a>
            <a href="#" className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors duration-200">
              Terms of Service
            </a>
            <a href="#" className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors duration-200">
              Cookie Policy
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;