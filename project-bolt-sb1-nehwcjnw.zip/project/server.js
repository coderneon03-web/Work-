const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const nodemailer = require('nodemailer');
const rateLimit = require('express-rate-limit');
const helmet = require('helmet');
const path = require('path');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'dist')));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // limit each IP to 100 requests per windowMs
});
app.use(limiter);

// Email configuration
const transporter = nodemailer.createTransporter({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// Store data (in production, this would be in a database)
const products = {
  ranks: [
    {
      id: 'blizz',
      name: 'Blizz Rank',
      price: 1.80,
      description: 'Good perks + Discord role',
      features: ['Basic permissions', 'Discord role', 'Kit access', 'Priority support']
    },
    {
      id: 'frozen',
      name: 'Frozen Rank',
      price: 3.24,
      description: 'Bonus kits + Discord role',
      features: ['Enhanced permissions', 'Exclusive Discord role', 'Multiple kits', 'Fast support']
    },
    {
      id: 'mythic',
      name: 'Mythic Rank',
      price: 4.05,
      description: 'Awesome Netherite kit + perks',
      features: ['Premium permissions', 'Mythic Discord role', 'Netherite kit', 'VIP support']
    },
    {
      id: 'aurora',
      name: 'Aurora Rank',
      price: 5.78,
      description: 'Top-tier perks & recognition',
      features: ['All permissions', 'Elite Discord role', 'All kits', 'Instant support', 'Special perks']
    }
  ],
  kits: [
    {
      id: 'starter-kit',
      name: 'Starter Kit',
      price: 0.99,
      description: 'Iron gear essentials',
      features: ['Full iron armor set', 'Iron tools (sword, pickaxe, axe)', 'Food supplies', 'Basic building blocks']
    },
    {
      id: 'blizz-kit',
      name: 'Blizz Kit',
      price: 1.80,
      description: 'Everyday essentials',
      features: ['Basic tools', 'Food supplies', 'Building blocks', 'Starter gear']
    },
    {
      id: 'frozen-kit',
      name: 'Frozen Kit',
      price: 3.24,
      description: 'Construction resources',
      features: ['Advanced tools', 'Premium blocks', 'Construction materials', 'Decorative items']
    },
    {
      id: 'mythic-kit',
      name: 'Mythic Kit',
      price: 4.05,
      description: 'Combat gear',
      features: ['Enchanted weapons', 'Armor sets', 'Combat potions', 'Rare materials']
    },
    {
      id: 'aurora-kit',
      name: 'Aurora Kit',
      price: 5.78,
      description: 'Premium rotating loot',
      features: ['Legendary items', 'Exclusive gear', 'Rare blocks', 'Special effects', 'Monthly updates']
    }
  ]
};

// API Routes
app.get('/api/products', (req, res) => {
  res.json(products);
});

app.post('/api/contact', async (req, res) => {
  try {
    const { name, email, message } = req.body;
    
    if (!name || !email || !message) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: 'coderneon03@gmail.com',
      subject: `New Contact Form Submission from ${name}`,
      html: `
        <h3>New Contact Form Submission</h3>
        <p><strong>Name:</strong> ${name}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Message:</strong></p>
        <p>${message}</p>
      `
    };

    await transporter.sendMail(mailOptions);
    res.json({ success: true, message: 'Message sent successfully!' });
  } catch (error) {
    console.error('Email error:', error);
    res.status(500).json({ error: 'Failed to send message' });
  }
});

app.post('/api/purchase', (req, res) => {
  const { productId, paypalOrderId, userEmail } = req.body;
  
  // In production, verify the PayPal payment here
  // For now, we'll just simulate a successful purchase
  
  console.log(`Purchase processed: ${productId} for ${userEmail}`);
  
  res.json({ 
    success: true, 
    message: 'Purchase completed successfully!',
    orderId: paypalOrderId
  });
});

// Serve React app for all other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});